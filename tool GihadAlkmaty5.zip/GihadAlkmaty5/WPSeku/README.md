# WPSeku - Simple Wordpress Security Scanner

__WPSeku__ is a black box WordPress vulnerability scanner that can be used to scan remote WordPress installations to find security issues.


## Screenshots

![screen1](https://i.imgur.com/VrkQnQp.png)

![screen2](https://i.imgur.com/R1uF4H7.png)
